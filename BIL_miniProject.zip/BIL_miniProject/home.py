from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import SelectField, SubmitField
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

app = Flask(__name__)
app.config['SECRET_KEY'] = 'you-will-never-guess'

class LinRegForm(FlaskForm):
    fileName = SelectField('Select one dataset', choices = [('Salary_Data.csv', 'Salary Data'), ('Mall_Customers.csv', 'Mall Custiomers Data')])
    submit = SubmitField('Submit')

class ClusForm(FlaskForm):
    clusFile = SelectField('Select one dataset', choices = [('Salary_Data.csv', 'Salary Data'), ('Mall_Customers.csv', 'Mall Custiomers Data')])
    clusSubmit = SubmitField('Submit')

@app.route('/', methods = ['GET', 'POST'])
def dashboard():
   return render_template('index.html')

@app.route('/linReg', methods=['GET', 'POST'])
def linReg():
    fileName = False
    form = LinRegForm()
    if form.validate_on_submit():
        fileName = form.fileName.data

        # Simple Linear Regression

        # Importing the dataset
        dataset = pd.read_csv('datasets/' + fileName)
        X = dataset.iloc[:, :-1].values
        y = dataset.iloc[:, 1].values

        # Splitting the dataset into the Training set and Test set
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 1/3, random_state = 0)

        # Feature Scaling
        """from sklearn.preprocessing import StandardScaler
        sc_X = StandardScaler()
        X_train = sc_X.fit_transform(X_train)
        X_test = sc_X.transform(X_test)
        sc_y = StandardScaler()
        y_train = sc_y.fit_transform(y_train)"""

        # Fitting Simple Linear Regression to the Training set
        from sklearn.linear_model import LinearRegression
        regressor = LinearRegression()
        regressor.fit(X_train, y_train)

        # Predicting the Test set results
        y_pred = regressor.predict(X_test)

        # Visualising the Training set results
        plt.scatter(X_train, y_train, color = 'red')
        plt.plot(X_train, regressor.predict(X_train), color = 'blue')
        plt.title('Salary vs Experience (Training set)')
        plt.xlabel('Years of Experience')
        plt.ylabel('Salary')
        plt.show()

        # Visualising the Test set results
        plt.scatter(X_test, y_test, color = 'red')
        plt.plot(X_train, regressor.predict(X_train), color = 'blue')
        plt.title('Salary vs Experience (Test set)')
        plt.xlabel('Years of Experience')
        plt.ylabel('Salary')
        plt.show()
    return render_template('linearRegression.html', form = form, fileName = fileName)

@app.route('/clus', methods = ['GET', 'POST']) 
def clus():
    clusFile = False
    clusForm = ClusForm()
    if clusForm.validate_on_submit():
        clusFile = clusForm.clusFile.data
        
        # Importing the dataset
        dataset = pd.read_csv('datasets/' + clusFile)
        X = dataset.iloc[:, [3, 4]].values
        # y = dataset.iloc[:, 3].values

        # Splitting the dataset into the Training set and Test set
        """from sklearn.cross_validation import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)"""

        # Feature Scaling
        """from sklearn.preprocessing import StandardScaler
        sc_X = StandardScaler()
        X_train = sc_X.fit_transform(X_train)
        X_test = sc_X.transform(X_test)
        sc_y = StandardScaler()
        y_train = sc_y.fit_transform(y_train)"""

        # Using the elbow method to find the optimal number of clusters
        from sklearn.cluster import KMeans
        wcss = []
        for i in range(1, 11):
            kmeans = KMeans(n_clusters = i, init = 'k-means++', random_state = 42)
            kmeans.fit(X)
            wcss.append(kmeans.inertia_)
        plt.plot(range(1, 11), wcss)
        plt.title('The Elbow Method')
        plt.xlabel('Number of clusters')
        plt.ylabel('WCSS')
        plt.show()

        # Fitting K-Means to the dataset
        kmeans = KMeans(n_clusters = 5, init = 'k-means++', random_state = 42)
        y_kmeans = kmeans.fit_predict(X)

        # Visualising the clusters
        plt.scatter(X[y_kmeans == 0, 0], X[y_kmeans == 0, 1], s = 100, c = 'red', label = 'Cluster 1')
        plt.scatter(X[y_kmeans == 1, 0], X[y_kmeans == 1, 1], s = 100, c = 'blue', label = 'Cluster 2')
        plt.scatter(X[y_kmeans == 2, 0], X[y_kmeans == 2, 1], s = 100, c = 'green', label = 'Cluster 3')
        plt.scatter(X[y_kmeans == 3, 0], X[y_kmeans == 3, 1], s = 100, c = 'cyan', label = 'Cluster 4')
        plt.scatter(X[y_kmeans == 4, 0], X[y_kmeans == 4, 1], s = 100, c = 'magenta', label = 'Cluster 5')
        plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s = 300, c = 'yellow', label = 'Centroids')
        plt.title('Clusters of customers')
        plt.xlabel('Annual Income (k$)')
        plt.ylabel('Spending Score (1-100)')
        plt.legend()
        plt.show()

    return render_template('clustering.html', clusForm = clusForm, clusFile = clusFile)

if __name__ == '__main__':
   app.run(debug = True)